kubectl autoscale deployment upg-loadme -n demo --cpu-percent=50 --min=1 --max=5
