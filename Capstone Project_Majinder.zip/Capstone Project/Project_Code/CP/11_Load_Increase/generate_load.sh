#####update the below URL with upg-loadme web accessible link
ab -n100 -c10 'http://aws-load-balancer-controller-1316571037.us-east-1.elb.amazonaws.com:80'
